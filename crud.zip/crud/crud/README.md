# React + Vite


  // for function rafce

  // for class rcce


  const root = document.getElementById('app');

  <BrowserRouter>
    <App />
    </BrowserRouter>