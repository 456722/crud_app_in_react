

 import React from 'react'
 
 const Home = () => {
    let b = 10;
   return (
    <>
     <div>Home</div>
     <h1>{b}</h1>
     </>
   )
 }
 
 export default Home
 