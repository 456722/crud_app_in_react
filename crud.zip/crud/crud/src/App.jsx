

import React from "react";
import Create from "./Components/Create";

import Read from "./Components/Read";
import {  Route, Routes, useNavigate } from "react-router-dom";
import MyForm from "./Components/Lform";
import Edit from "./Components/Edit";


const App = () => {
  
  return (
   <> 
     
      {/* <MyForm/> */}

   <div className="container">
    <Routes>
      <Route exact path="/" element={<Read/>}></Route>
      <Route exact path="/create" element={<Create/>}></Route>
      <Route exact path="/edit" element={<Edit/>}></Route>
    </Routes>
   </div>
  
    
   </>
  );
}

export default App;
