

import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Read() {
  const [apiData, setApiData] = useState([]);

  // getdata function ko useEffect ke scope mein define karen
  const getdata = () => {
    axios.get('https://65f9522edf15145246112b48.mockapi.io/crud')
      .then((response) => {
        setApiData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  };

  // useEffect to fetch data
  useEffect(() => {
    getdata(); // Call getdata function
  }, []);

  function handleDelete(id) {
    axios.delete(`https://65f9522edf15145246112b48.mockapi.io/crud/${id}`)
      .then(() => {
        // Data delete hone ke baad getdata function ko phir se call karen
        getdata();
      })
      .catch((error) => {
        console.error('Error deleting data:', error);
      });
  }

   function setDataToStorage (id,name,age,email){
    localStorage.setItem('id',id);
    localStorage.setItem('name',name);
    
    localStorage.setItem('age',age);
    localStorage.setItem('email',email);
    
   }

  return (
    <>
      <div className='row'>
        <div className='col-md-12'>
          <div className='mb-2 mt-2'>
            <Link to='/create'>
              <button className='btn btn-primary'>Create New Data</button>
            </Link>
          </div>
          <table className='table table-bordered table-striped table-dark table-hover'>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Email</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {apiData.map((item) => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.e_name}</td>
                  <td>{item.e_age}</td>
                  <td>{item.e_email}</td>
                  <td>
                   <Link to={'/edit'}>
                   <button className='btn btn-primary' onClick={()=>setDataToStorage(item.id,item.e_name,item.e_age,item.e_email)}>
                      Edit
                    </button> 
                   </Link>
                  </td>
                  <td>
                    <button
                      className='btn btn-danger'
                      onClick={() => {
                        if (window.confirm('Are you Sure Delete this data')) {
                          handleDelete(item.id);
                        }
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default Read;
