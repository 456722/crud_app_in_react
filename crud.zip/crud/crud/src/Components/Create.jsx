
import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
  
// const navigate  =  useNavigate();
const Create = () => {
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [email, setEmail] = useState('');
     const navigate = useNavigate()
    const handle_create = (e) => {
        e.preventDefault();
        console.log(name, age, email);
        axios.post('https://65f9522edf15145246112b48.mockapi.io/crud', {
            e_name: name,
            e_age: age,
            e_email: email
        }).then(response => {
            navigate('/')
            console.log("Data created successfully:", response.data);
            // Add any success message or redirect user to another page as per your requirement
        }).catch(error => {
            console.error("Error occurred while creating data:", error);
            // Handle error as per your requirement
        });
    };

    return (
        <>
        <div className='row'>
            <div className='col-md-4 p-4 text-center' >
            <div className='mb-2 mt-2'>
            <Link to='/'>
            <button className='btn btn-primary'>Read Data</button>
            </Link>
            
          </div>
                <div className='bg-primary'>
                    <h1>Create Data</h1>
                </div>
                <form onSubmit={handle_create}>
                    <div className="form-group">
                        <label>Enter Name:</label>
                        <input type="text" placeholder='Name' value={name} onChange={(e) => setName(e.target.value)} className='form-control' />
                    </div>
                    <div className="form-group">
                        <label>Enter Age:</label>
                        <input type="number" placeholder='Enter Age' value={age} onChange={(e) => setAge(e.target.value)} className='form-control' />
                    </div>
                    <div className="form-group">
                        <label>Enter Email:</label>
                        <input type="email" placeholder='Enter Email' value={email} onChange={(e) => setEmail(e.target.value)} className='form-control' />
                    </div>
                    <br />
                    <div className='d-grid'>
                        <button type="submit" className='btn btn-primary'>Submit</button>
                    </div>
                </form>
                {name}
                <br/>
                {age}
                <br/>
                {email}
            </div>
        </div>
        </>
    );
}

export default Create;

  